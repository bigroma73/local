#!/bin/sh
#DESCRIPTION=This script will show you the free memory of your box
free
echo ""
exit 0