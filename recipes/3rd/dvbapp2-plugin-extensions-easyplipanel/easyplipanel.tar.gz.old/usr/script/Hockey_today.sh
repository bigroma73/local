#!/bin/sh
# title:1.3.хоккейные результаты сегодня 

URL=http://www.livescore.ru/hockey/today/
TIMEDIFF=60 # Обновление каждую минуту
NOW=`date +'%s'`
TMPFILE=/tmp/hk.xml

DOWNLOAD=1
if [ -f ${TMPFILE} ]; then 
   DFILE=` stat -c %Z ${TMPFILE}`
   CURDIFF=$(($NOW - $DFILE))
   if [ $CURDIFF  -lt $TIMEDIFF ]  ; then 
     DOWNLOAD=0
   fi             
fi    


if [ $DOWNLOAD == "1" ]; then 
 wget $URL  -O /tmp/temp.xml  >/dev/null 2>&1
fi  

if [ $? == 0 ] && [ $DOWNLOAD == "1" ] ;  then 
  cp -f /tmp/temp.xml ${TMPFILE}
fi

if [ -f ${TMPFILE} ]; then 
  cat ${TMPFILE} | awk '
BEGIN{

}
function convert(cstring){
newstr=""
num= split(cstring, tmpstr, //) 
 for (i=1;i<=num;i++){
 
	if(tmpstr[i]~/\xE0/){
		sub(/\xE0/,"а",tmpstr[i]);
	}else if(tmpstr[i]~/\xE1/){
		sub(/\xE1/,"б",tmpstr[i]);
	}else if(tmpstr[i]~/\xE2/){
		sub(/\xE2/,"в",tmpstr[i]);
	}else if(tmpstr[i]~/\xE3/){
		sub(/\xE3/,"г",tmpstr[i]);
	}else if(tmpstr[i]~/\xE4/){
		sub(/\xE4/,"д",tmpstr[i]);
	}else if(tmpstr[i]~/\xE5/){
		sub(/\xE5/,"е",tmpstr[i]);
	}else if(tmpstr[i]~/\xE6/){
		sub(/\xE6/,"ж",tmpstr[i]);
	}else if(tmpstr[i]~/\xE7/){
		sub(/\xE7/,"з",tmpstr[i]);
	}else if(tmpstr[i]~/\xE8/){
		sub(/\xE8/,"и",tmpstr[i]);
	}else if(tmpstr[i]~/\xE9/){
		sub(/\xE9/,"й",tmpstr[i]);
	}else if(tmpstr[i]~/\xEA/){
		sub(/\xEA/,"к",tmpstr[i]);
	}else if(tmpstr[i]~/\xEB/){
		sub(/\xEB/,"л",tmpstr[i]);
	}else if(tmpstr[i]~/\xEC/){
		sub(/\xEC/,"м",tmpstr[i]);
	}else if(tmpstr[i]~/\xED/){
		sub(/\xED/,"н",tmpstr[i]);
	}else if(tmpstr[i]~/\xEE/){
		sub(/\xEE/,"о",tmpstr[i]);
	}else if(tmpstr[i]~/\xEF/){
		sub(/\xEF/,"п",tmpstr[i]);
	}else if(tmpstr[i]~/\xF0/){
		sub(/\xF0/,"р",tmpstr[i]);
	}else if(tmpstr[i]~/\xF1/){
		sub(/\xF1/,"с",tmpstr[i]);
	}else if(tmpstr[i]~/\xF2/){
		sub(/\xF2/,"т",tmpstr[i]);
	}else if(tmpstr[i]~/\xF3/){
		sub(/\xF3/,"у",tmpstr[i]);
	}else if(tmpstr[i]~/\xF4/){
		sub(/\xF4/,"ф",tmpstr[i]);
	}else if(tmpstr[i]~/\xF5/){
		sub(/\xF5/,"х",tmpstr[i]);
	}else if(tmpstr[i]~/\xF6/){
		sub(/\xF6/,"ц",tmpstr[i]);
	}else if(tmpstr[i]~/\xF7/){
		sub(/\xF7/,"ч",tmpstr[i]);
	}else if(tmpstr[i]~/\xF8/){
		sub(/\xF8/,"ш",tmpstr[i]);
	}else if(tmpstr[i]~/\xF9/){
		sub(/\xF9/,"щ",tmpstr[i]);
	}else if(tmpstr[i]~/\xFA/){
		sub(/\xFA/,"ъ",tmpstr[i]);
	}else if(tmpstr[i]~/\xFB/){
		sub(/\xFB/,"ы",tmpstr[i]);
	}else if(tmpstr[i]~/\xFC/){
		sub(/\xFC/,"ь",tmpstr[i]);
	}else if(tmpstr[i]~/\xFD/){
		sub(/\xFD/,"э",tmpstr[i]);
	}else if(tmpstr[i]~/\xFE/){
		sub(/\xFE/,"ю",tmpstr[i]);
	}else if(tmpstr[i]~/\xFF/){
		sub(/\xFF/,"я",tmpstr[i]);
	}else if(tmpstr[i]~/\xC0/){
		sub(/\xC0/,"А",tmpstr[i]);
	}else if(tmpstr[i]~/\xC1/){
		sub(/\xC1/,"Б",tmpstr[i]);
	}else if(tmpstr[i]~/\xC2/){
		sub(/\xC2/,"В",tmpstr[i]);
	}else if(tmpstr[i]~/\xC3/){
		sub(/\xC3/,"Г",tmpstr[i]);
	}else if(tmpstr[i]~/\xC4/){
		sub(/\xC4/,"Д",tmpstr[i]);
	}else if(tmpstr[i]~/\xC5/){
		sub(/\xC5/,"Е",tmpstr[i]);
	}else if(tmpstr[i]~/\xC6/){
		sub(/\xC6/,"Ж",tmpstr[i]);
	}else if(tmpstr[i]~/\xC7/){
		sub(/\xC7/,"З",tmpstr[i]);
	}else if(tmpstr[i]~/\xC8/){
		sub(/\xC8/,"И",tmpstr[i]);
	}else if(tmpstr[i]~/\xC9/){
		sub(/\xC9/,"Й",tmpstr[i]);
	}else if(tmpstr[i]~/\xCA/){
		sub(/\xCA/,"К",tmpstr[i]);
	}else if(tmpstr[i]~/\xCB/){
		sub(/\xCB/,"Л",tmpstr[i]);
	}else if(tmpstr[i]~/\xCC/){
		sub(/\xCC/,"М",tmpstr[i]);
	}else if(tmpstr[i]~/\xCD/){
		sub(/\xCD/,"Н",tmpstr[i]);
	}else if(tmpstr[i]~/\xCE/){
		sub(/\xCE/,"О",tmpstr[i]);
	}else if(tmpstr[i]~/\xCF/){
		sub(/\xCF/,"П",tmpstr[i]);
	}else if(tmpstr[i]~/\xD0/){
		sub(/\xD0/,"Р",tmpstr[i]);
	}else if(tmpstr[i]~/\xD1/){
		sub(/\xD1/,"С",tmpstr[i]);
	}else if(tmpstr[i]~/\xD2/){
		sub(/\xD2/,"Т",tmpstr[i]);
	}else if(tmpstr[i]~/\xD3/){
		sub(/\xD3/,"У",tmpstr[i]);
	}else if(tmpstr[i]~/\xD4/){
		sub(/\xD4/,"Ф",tmpstr[i]);
	}else if(tmpstr[i]~/\xD5/){
		sub(/\xD5/,"Х",tmpstr[i]);
	}else if(tmpstr[i]~/\xD6/){
		sub(/\xD6/,"Ц",tmpstr[i]);
	}else if(tmpstr[i]~/\xD7/){
		sub(/\xD7/,"Ч",tmpstr[i]);
	}else if(tmpstr[i]~/\xD8/){
		sub(/\xD8/,"Ш",tmpstr[i]);
	}else if(tmpstr[i]~/\xD9/){
		sub(/\xD9/,"Щ",tmpstr[i]);
	}else if(tmpstr[i]~/\xDA/){
		sub(/\xDA/,"Ъ",tmpstr[i]);
	}else if(tmpstr[i]~/\xDB/){
		sub(/\xDB/,"Ю",tmpstr[i]);
	}else if(tmpstr[i]~/\xDC/){
		sub(/\xDC/,"Ь",tmpstr[i]);
	}else if(tmpstr[i]~/\xDD/){
		sub(/\xDD/,"Э",tmpstr[i]);
	}else if(tmpstr[i]~/\xDE/){
		sub(/\xDE/,"Ю",tmpstr[i]);
	}else if(tmpstr[i]~/\xDF/){
		sub(/\xDF/,"Я",tmpstr[i]);
	}else if(tmpstr[i]~/\xBB/){
		sub(/\xBB/,"\"",tmpstr[i]);
	}else if(tmpstr[i]~/\xAB/){
		sub(/\xAB/,"\"",tmpstr[i]);
	}else if(tmpstr[i]~/\xB2/){
		sub(/\xB2/,"I",tmpstr[i]);
	}else if(tmpstr[i]~/\xB3/){
		sub(/\xB3/,"i",tmpstr[i]);
	}else if(tmpstr[i]~/\xA2/){
		sub(/\xA2/,"y",tmpstr[i]);
	}else if(tmpstr[i]~/\x96/){
		sub(/\x96/,"-",tmpstr[i]);
	
	}

   newstr=newstr tmpstr[i];
 }
return newstr


} 



{
    if ( $_ ~  /<DIV class=pl_big_text>.*<\/DIV><\/DIV><DIV/ ){
       sub(/.*<DIV class=pl_big_text>/,"");
       title= convert($_)       
        if ( title ~ /IMG/){
	   sub(/<\/DIV>.*/,"",title);       
           print "****************************\n"title
	}

    }else if ( $_ ~  /<DIV class=pl_live_date>/ ){	
           sub(/<DIV class=pl_live_date>/,"")
	   date=convert($_)
           gsub(/<.*/,"",date)	   
	   print date  
    }else if ( $_ ~  /<DIV class=l_h_ti><img/ ){	
           sub(/^.*gif">/,"")
	      time=convert($_)
           gsub(/<.*/,"",time)
	   print "----------------------------\n" time
    }else if ( $_ ~  /<DIV class=l_h_te>/ ){		   
           sub(/<DIV class=l_h_te>/,"")	   
	   sub(/<\/DIV>/,"")	   
           gsub(/<BR>/," ")	   	   
	   gsub(/&#229/,"a")
	   gsub(/&#237/,"i")
	   gsub(/&#225/,"a")
	   gsub(/&#233/,"e")	   
	   gsub(/&#248/,"o")
	   name=convert($_)
	   sub(/\n/,"",name);

    }else if ($_ ~ /<DIV class=l_h_sc>/){
     
      gsub(/.*<DIV class=l_h_sc>/,"");
      gsub(/<DIV class=l_h_sc_in_b>/, "");      
      gsub(/<DIV class=l_h_sc_in>/,"");            
      
      gsub(/<\/DIV>/," ");      
      print name" "$_

   }

}
  

'   
else 
  echo "Не могу загрузить данные с сайта."
fi
sleep 2

rm  /tmp/temp.xml
rm  /tmp/hk.xml

