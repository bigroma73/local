#!/bin/sh
 

date 
echo "***********************************************"
echo "Begin_Testing router (Edimax 192.168.1.1)" >> /tmp/ping1.txt
data="`ping -c 1 192.168.1.1 | grep '100%'`"
if [ "$data" = "" ];
then
echo "Router Edimax OK" >> /tmp/ping1.txt
else
echo "Router Edimax NOT WORK" >> /tmp/ping1.txt
fi
echo "Begin_Testing router (Linksys 192.168.1.2)" >> /tmp/ping1.txt
data="`ping -c 1 192.168.1.2 | grep '100%'`"
if [ "$data" = "" ];
then
echo "Router Linksys OK" >> /tmp/ping1.txt
else
echo "Router Linksys NOT WORK" >> /tmp/ping1.txt
fi
echo "Begin_Testing internet (rus.delfi.lv)" >> /tmp/ping1.txt
data="`ping -c 1 62.63.137.6 | grep '100%'`"
if [ "$data" = "" ];
then
echo "Internet OK" >> /tmp/ping1.txt
else
echo "Internet NOT WORK" >> /tmp/ping1.txt
fi
echo "Begin_Testing sharing (server1)" >> /tmp/ping1.txt
data="`ping -c 1 xx.xxx.xxx.xxx | grep '100%'`"
if [ "$data" = "" ];
then
echo "Sharing OK" >> /tmp/ping1.txt
else
echo "Sharing NOT WORK" >> /tmp/ping1.txt
fi
echo "Begin_Testing sharing (Trikolor )" >> /tmp/ping1.txt
data="`ping -c 1 xx.xxxx.xxx.xx | grep '100%'`"
if [ "$data" = "" ];
then
echo "Sharing OK" >> /tmp/ping1.txt
else
echo "Sharing NOT WORK" >> /tmp/ping1.txt
fi
sleep 2
cat /tmp/ping1.txt


sleep 1
rm -f /tmp/ping1.txt
exit 0 