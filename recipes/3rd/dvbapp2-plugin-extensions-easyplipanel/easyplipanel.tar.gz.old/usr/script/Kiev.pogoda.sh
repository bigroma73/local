#!/bin/sh
# title:1.5.Прогноз погоды в Лиепае
# Прогноз погоды rb5.ru  by stpavel  v 0.1
# Для настройки перейдите на сайт http://rp5.ru/ 
# Найдите свой код города  ( например для Тольятти ссылка будет http://rp5.ru/8210/ru , где 8210 код города ) 
# Исправьте значение CITY на свой код города. 
# Внимание !!!  Между CITY и кодом города должнен быть только знак = (равно), никаких пробелов !!!
#
CITY=9821
#
############################################ 
URL=http://rp5.lv/xml/233/ru 
TIMEDIFF=3600 # Обновление каждый  час
NOW=`date +'%s'`
if [ -e /tmp/weather1.xml ]; then 
   rm  /tmp/weather1.xml
               
fi 

DOWNLOAD=1
if [ -f /tmp/weather1.xml ]; then 
   DFILE=` stat -c %Z /tmp/weather1.xml`
   CURDIFF=$(($NOW - $DFILE))
   if [ $CURDIFF  -lt $TIMEDIFF ]  ; then 
     DOWNLOAD=0
   fi             
fi    


if [ $DOWNLOAD == "1" ]; then 
 #wget $URL  -O /tmp/temp.xml  >/dev/null 2>&1
  wget $URL  -O /tmp/temp.xml -U Opera >/dev/null 2>&1
fi  

if [ $? == 0 ] && [ $DOWNLOAD == "1" ] ;  then 
  cp -f /tmp/temp.xml /tmp/weather1.xml 
fi

if [ -f /tmp/weather1.xml ]; then 
  cat /tmp/weather1.xml | awk '
BEGIN{
 month[1]="января"
 month[2]="февраля" 
 month[3]="марта"  
 month[4]="апреля" 
 month[5]="мая"   
 month[6]="июня"  
 month[7]="июля"  
 month[8]="августа"  
 month[9]="сентября"  
 month[10]="октября"  
 month[11]="ноября"  
 month[12]="декабря"  
}
{

  if ( /<wind_direction>/ ){
     if (/\xD1-\xC7/){
      wind_direction="северо-западный"
     }else if (/\xD1-\xC2/){
      wind_direction="северо-восточный"     
     }else if (/\xDE-\xC7/){
      wind_direction="юго-западный"
     }else if (/\xDE-\xC2/){      
      wind_direction="юго-восточный"     
     }else if (/\xDE/){
      wind_direction="южный"
     }else if (/\xD1/){
      wind_direction="северный"
     }else if (/\xC2/){
      wind_direction= "восточный"	 	 
     }else if (/\xC7/){
      wind_direction="западный"	 
     }	 
 }else if (/<datetime>/){
   sub(/<datetime>/,"");
   sub(/<\/datetime>.*$/,"");   
   sub(/-/," ");      
   sub(/-/," ");      
   datetime= $3 " " month[$2] " " $1 ", " $4
 }else if  (/cloud_cover>/ ){ # Облачность
   sub(/<cloud_cover>/,"");
   sub(/<\/cloud_cover>.*$/,"");   
   if ($1 <= 10){
     cloud_cover = "ясно (облачность "$1"%)" ;
   }else if ($1<=30){
     cloud_cover = "малооблачно (облачность "$1"%)" ;        
   }else if ($1<=50){
     cloud_cover = "переменная облачность ("$1"%)" ;        
   }else if ($1<=80){
     cloud_cover = "облачно (облачность "$1"%)" ;        
   }else{
     cloud_cover = "пасмурная погода (облачность "$1"%)" ;        
   } 

 }else if  (/precipitation/ ){ # Осадки
   sub(/<precipitation>/,"");
   sub(/<\/precipitation>.*$/,"");   
   if ( $1 == 0.0){
    precipitation="без осадков"
   }else if ( $1 <= 0.1){   
    precipitation="преимущественно без осадков ("$1"мм/6 час)"
   }else if ( $1 <= 4){   
    precipitation="осадки ("$1"мм/6 час)"
  }else{    
    precipitation="сильные осадки ("$1"мм/6 час)"   
  }    
 }else if  (/pressure/ ){ # Давление
   sub(/<pressure>/,"");
   sub(/<\/pressure>.*$/,"");   
   pressure="давление "$1" мм"
 }else if  (/temperature/ ){ # Температура
   sub(/<temperature>/,"");
   sub(/<\/temperature>.*$/,"");   
   temperature=$1"°C";
 }else if  (/humidity/ ){ # Влажность
   sub(/<humidity>/,"");
   sub(/<\/humidity>.*$/,"");   
   humidity="влажность "84"%";   
 }else if  (/wind_velocity/ ){ # Скорость ветра
   sub(/<wind_velocity>/,"");
   sub(/<\/wind_velocity>.*$/,"");   
   wind_velocity=$1" м/с"
 }else if  (/falls>/ ){ # Тип осадков
   sub(/<falls>/,"");
   sub(/<\/falls>.*$/,"");   
   if ($1==1){
     falls="дождь"
  }else if($1==2){     
     falls="дождь со снегом"  
  }else if($1==3){          
       falls="снег"  
  }else{
       falls=""           
  }
 }else if  ( $_ ~ /<drops>/ ){
   print datetime  "\n "temperature ", ветер "wind_direction "," wind_velocity ", "  precipitation  ", " cloud_cover ", " pressure ", " humidity "\n________________________________________________\n"
 }  
}
END{
#
}

'   
else 
  echo "Не могу загрузить данные с сайта."
fi
sleep 2
rm  /tmp/weather1.xml