#!/bin/sh
#DESCRIPTION=This script will show you the mount-points mounted on the box
mount
echo ""
exit 0