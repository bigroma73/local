#!/bin/sh
# 

echo "Net diagnostik"


echo "----------------------------------------"
echo '' > /tmp/ping.txt
IP_ADDR=`cat /usr/keys/newcamd.list |  grep -v "^ *#" | grep "CWS *=" | sed -e s'/=//' | awk '{print $2}' | sort -u`
for IP in $IP_ADDR ; do 
  ping -c 4 $IP | tail -n3 >> /tmp/ping.txt
done

cat /tmp/ping.txt



exit 0