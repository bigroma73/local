#!/bin/sh
#DESCRIPTION=This script will show you the performance of your internet-connection
echo "Ping google.de:"
ping -c 1 www.google.de
echo "*****************************"
echo "Ping stern.de:"
ping -c 1 www.stern.de
echo "*****************************"
echo ""
exit 0
