#!/bin/sh
#DESCRIPTION=This script will show all processes currently running on your box
ps
echo ""
exit 0