#!/bin/sh
#DESCRIPTION=This script will show you the free space of the box
opkg list | grep dvb-modules