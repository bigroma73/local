#!/bin/sh
#DESCRIPTION=This script will show you all loaded kernel-modules
lsmod
echo ""
exit 0